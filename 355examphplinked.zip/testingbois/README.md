# HatTrick

https://term-project.glitch.me/





https://glitch.com/edit/#!/join/eed18d9e-75af-4f1c-b386-7644c62ff5c2

FILES on Glitch -> Github:




index.html -> home.html
